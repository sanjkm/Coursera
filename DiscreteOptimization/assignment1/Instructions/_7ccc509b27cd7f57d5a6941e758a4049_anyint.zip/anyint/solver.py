#!/usr/bin/python
# -*- coding: utf-8 -*-

def solve_it(input_data):
    # return a positive integer, as a string
    return '0'

if __name__ == '__main__':
    print('This script submits the integer: %s\n' % solve_it(''))

